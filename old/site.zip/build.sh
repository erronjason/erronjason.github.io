#! /bin/sh
python make_fs.py -d filesystem -o json/fs.json -i images
